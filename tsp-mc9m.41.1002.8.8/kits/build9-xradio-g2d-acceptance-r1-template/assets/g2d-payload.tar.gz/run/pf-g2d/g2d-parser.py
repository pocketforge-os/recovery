#!/usr/bin/env python3
"""Strict parsers for real v4l2-ctl and pf-v4l2-rotate output."""
import base64
import pathlib
import re
import sys


RAW_LIMIT = 384
DIAGNOSTIC_LIMITS = {
    "helper.stderr": (240, 500),
    "helper.stdout": (120, 300),
    "v4l2-compliance.summary": (180, 350),
    "rotate-receipt.tsv": (120, 260),
}


def refuse(reason: str, raw: bytes | None = None) -> None:
    print(f"G2D_PARSE_ERROR reason={reason}", file=sys.stderr)
    if raw is not None:
        shown = raw[:RAW_LIMIT]
        encoded = base64.b64encode(shown).decode("ascii")
        print(
            "G2D_PARSE_RAW encoding=base64 "
            f"bytes_total={len(raw)} bytes_shown={len(shown)} "
            f"truncated={int(len(raw) > len(shown))} data={encoded}",
            file=sys.stderr,
        )
    raise SystemExit(2)


def diagnostic_line(name: str, raw: bytes, *, head: bool = False) -> None:
    raw_limit, line_limit = DIAGNOSTIC_LIMITS[name]
    shown = raw[:raw_limit] if head else raw[-raw_limit:]
    encoded = base64.b64encode(shown).decode("ascii")
    line = (
        f"G2D_DIAG name={name} encoding=base64 "
        f"bytes_total={len(raw)} bytes_shown={len(shown)} data={encoded}"
    )
    if len((line + "\n").encode("utf-8")) > line_limit:
        refuse("diagnostic_limit_internal")
    print(line)


def failure_diagnostics(directory: pathlib.Path) -> None:
    try:
        helper_stderr = (directory / "helper.stderr").read_bytes()
        helper_stdout = (directory / "helper.stdout").read_bytes()
        compliance = (directory / "v4l2-compliance.txt").read_bytes()
        receipt_path = directory / "rotate" / "rotate-receipt.tsv"
        receipt = receipt_path.read_bytes() if receipt_path.is_file() else b""
    except OSError:
        refuse("diagnostic_input_unreadable")
    summary = b"\n".join(
        line for line in compliance.splitlines()
        if b"Total" in line or b"FAIL" in line
    )
    if summary:
        summary += b"\n"
    diagnostic_line("helper.stderr", helper_stderr)
    diagnostic_line("helper.stdout", helper_stdout)
    diagnostic_line("v4l2-compliance.summary", summary)
    diagnostic_line("rotate-receipt.tsv", receipt, head=True)


if len(sys.argv) < 3:
    refuse("usage")
mode = sys.argv[1]
path = pathlib.Path(sys.argv[2])
if mode == "failure-diagnostics":
    if len(sys.argv) != 3 or not path.is_dir():
        refuse("failure_diagnostics_usage")
    failure_diagnostics(path)
    raise SystemExit(0)
try:
    raw = path.read_bytes()
    text = raw.decode("utf-8")
except (OSError, UnicodeDecodeError):
    refuse("input_unreadable")

if mode == "v4l2-driver":
    driver_info = text.split("Media Driver Info:", 1)[0]
    values = re.findall(r"^[ \t]*Driver name[ \t]*:[ \t]*(\S+)[ \t]*$", driver_info,
                        re.MULTILINE)
    if len(values) != 1:
        refuse("driver_missing_or_duplicate", raw)
    print(values[0])
elif mode == "receipt-field":
    if len(sys.argv) != 4 or not re.fullmatch(r"[a-z0-9_]+", sys.argv[3]):
        refuse("receipt_field_usage")
    key = sys.argv[3]
    values = [line.split("\t", 1)[1] for line in text.splitlines()
              if line.startswith(key + "\t") and "\t" in line]
    if len(values) != 1 or not values[0] or "\t" in values[0]:
        refuse("receipt_field_missing_or_duplicate", raw)
    print(values[0])
else:
    refuse("mode_unknown", raw)
