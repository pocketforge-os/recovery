#!/usr/bin/env python3
"""Export a rotate receipt in at most two bounded DutExec responses."""
import base64
import gzip
import hashlib
import pathlib
import sys

CHUNK = 2000
RAW_MAX = 16384

if len(sys.argv) != 3 or sys.argv[2] not in ("1", "2"):
    print("G2D_RECEIPT_EXPORT_ERROR reason=usage", file=sys.stderr)
    raise SystemExit(2)
path = pathlib.Path(sys.argv[1])
try:
    raw = path.read_bytes()
except OSError:
    print("G2D_RECEIPT_EXPORT_ERROR reason=input_unreadable", file=sys.stderr)
    raise SystemExit(2)
if not raw or len(raw) > RAW_MAX:
    print(f"G2D_RECEIPT_EXPORT_ERROR reason=raw_size bytes={len(raw)}", file=sys.stderr)
    raise SystemExit(2)
encoded = base64.b64encode(gzip.compress(raw, compresslevel=9, mtime=0)).decode("ascii")
parts = (len(encoded) + CHUNK - 1) // CHUNK
if parts > 2:
    print(f"G2D_RECEIPT_EXPORT_ERROR reason=encoded_size bytes={len(encoded)}", file=sys.stderr)
    raise SystemExit(2)
part = int(sys.argv[2])
common = (
    f"schema=v1 part={part} parts={parts} raw_bytes={len(raw)} "
    f"raw_sha256={hashlib.sha256(raw).hexdigest()} encoded_bytes={len(encoded)}"
)
if part > parts:
    print(f"G2D_RECEIPT_EXPORT {common} state=unused")
else:
    data = encoded[(part - 1) * CHUNK:part * CHUNK]
    print(f"G2D_RECEIPT_EXPORT {common} state=data data={data}")
