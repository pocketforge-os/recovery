#!/usr/bin/env python3
import pathlib, sys

root = pathlib.Path(sys.argv[1]) if len(sys.argv) == 2 else pathlib.Path("/")
if len(sys.argv) == 2 and __import__("os").environ.get("PF_DTB_PROOF_TEST_MODE") != "1":
    print("IMAGE_DTB_FAIL reason=test_override_forbidden")
    raise SystemExit(75)
names = root / "sys/firmware/devicetree/base/soc/clock-controller@6480000/clock-names"
clocks = root / "sys/firmware/devicetree/base/soc/clock-controller@6480000/clocks"
try:
    parsed = names.read_bytes().rstrip(b"\0").split(b"\0")
    raw = clocks.read_bytes()
except OSError:
    print("IMAGE_DTB_FAIL reason=live_fdt_unreadable")
    raise SystemExit(75)
if parsed != [b"bus", b"mod", b"mbus"] or len(raw) != 24:
    print(f"IMAGE_DTB_FAIL reason=mbus_property_mismatch names={','.join(x.decode('ascii','replace') for x in parsed)} clock_bytes={len(raw)}")
    raise SystemExit(75)
print("IMAGE_DTB_GATE source=image-owned node=/soc/clock-controller@6480000 clock_names=bus,mod,mbus clock_cells=6 status=pass")
