#!/usr/bin/env python3
"""Bounded, typed views of G2D job-completion producers."""
import pathlib
import re
import sys


def read(path: str, limit: int = 1024 * 1024) -> str:
    try:
        data = pathlib.Path(path).read_bytes()
    except OSError:
        return ""
    if len(data) > limit:
        data = data[-limit:]
    return data.decode("utf-8", "replace")


def bounded(lines: list[str], limit: int, empty: str) -> None:
    used = 0
    emitted = 0
    for line in lines:
        encoded = (line.rstrip("\r\n") + "\n").encode()
        if used + len(encoded) > limit:
            break
        sys.stdout.buffer.write(encoded)
        used += len(encoded)
        emitted += 1
    if not emitted:
        print(empty)
    elif emitted < len(lines):
        marker = f"G2D_DIAG_TRUNCATED shown={emitted} total={len(lines)}\n".encode()
        if used + len(marker) <= limit:
            sys.stdout.buffer.write(marker)


if len(sys.argv) < 3:
    raise SystemExit("G2D_DIAGNOSE_ERROR reason=usage")
mode, path = sys.argv[1:3]
text = read(path)
if mode == "helper-summary":
    counts: dict[str, int] = {}
    for line in text.splitlines():
        if line.startswith("PF_V4L2_ROTATE_FAIL "):
            counts[line] = counts.get(line, 0) + 1
        elif line.startswith("PF_V4L2_IOCTL "):
            rc = re.search(r"\brc=(-?\d+)\b", line)
            err = re.search(r"\berrno=(\d+)\b", line)
            expected_eagain = " step=dqbuf " in f" {line} " and err and err.group(1) == "11"
            if rc and int(rc.group(1)) < 0 and not expected_eagain:
                counts[line] = counts.get(line, 0) + 1
    rows = [f"G2D_HELPER_ERROR count={count} text={line}" for line, count in counts.items()]
    bounded(rows, 1000, "G2D_HELPER_ERROR state=absent")
elif mode == "interrupts":
    phase = sys.argv[3] if len(sys.argv) == 4 and sys.argv[3] in ("before", "after") else "invalid"
    if phase == "invalid":
        raise SystemExit("G2D_DIAGNOSE_ERROR reason=phase")
    rows = [f"G2D_IRQ phase={phase} text={line.strip()}" for line in text.splitlines()
            if re.search(r"sun8i-rotate|64a8000|g2d", line, re.I)]
    bounded(rows, 240, f"G2D_IRQ phase={phase} state=absent")
elif mode == "irq-delta":
    if len(sys.argv) != 4:
        raise SystemExit("G2D_DIAGNOSE_ERROR reason=irq_delta_usage")
    after_text = read(sys.argv[3])

    def irq_total(value: str) -> int | None:
        for line in value.splitlines():
            if not re.search(r"sun8i-rotate|64a8000|g2d", line, re.I) or ":" not in line:
                continue
            values = []
            for token in line.split(":", 1)[1].split():
                if not token.isdecimal():
                    break
                values.append(int(token))
            if values:
                return sum(values)
        return None

    before = irq_total(text)
    after = irq_total(after_text)
    if before is None or after is None:
        print("G2D_IRQ_DELTA state=unavailable")
    else:
        print(f"G2D_IRQ_DELTA before={before} after={after} delta={after - before}")
elif mode == "helper-trace":
    rows = [line for line in text.splitlines() if line.startswith("PF_V4L2_IOCTL ")]
    bounded(rows, 1200, "PF_V4L2_IOCTL state=absent")
elif mode == "job-outcome":
    rows = [line for line in text.splitlines() if line.startswith("PF_V4L2_IOCTL ")]
    max_ms = 0
    timeout = False
    error = False
    completed_types: set[str] = set()
    for line in rows:
        match = re.search(r"\bjob_ms=(\d+)\b", line)
        if match:
            max_ms = max(max_ms, int(match.group(1)))
        if re.search(r"\bstep=poll\b.*\brc=0\b", line) or re.search(r"\berrno=110\b", line):
            timeout = True
        if " step=dqbuf " in f" {line} " and " rc=0 " in f" {line} ":
            match = re.search(r"\btype=(output|capture)\b", line)
            if match:
                completed_types.add(match.group(1))
        elif re.search(r"\b(step=qbuf|step=streamon|step=dqbuf)\b", line) and \
                re.search(r"\brc=-[1-9][0-9]*\b", line) and " errno=11 " not in f" {line} ":
            error = True
    if timeout:
        outcome = "timeout"
    elif completed_types == {"output", "capture"} and not error:
        outcome = "completed"
    else:
        outcome = "error"
    print(f"G2D_JOB case=identity frames=1 outcome={outcome} elapsed_ms={max_ms}")
elif mode == "dmesg":
    rows = [f"G2D_DMESG text={line.strip()}" for line in text.splitlines()
            if re.search(r"sun8i-rotate|64a8000", line, re.I)][-8:]
    bounded(rows, 400, "G2D_DMESG state=absent")
elif mode == "iommu-delta":
    if len(sys.argv) != 4:
        raise SystemExit("G2D_DIAGNOSE_ERROR reason=iommu_delta_usage")
    after_text = read(sys.argv[3])
    pattern = re.compile(r"sun50i-iommu.*(?:page fault|fault).*master(?:=| )5", re.I)
    before = sum(bool(pattern.search(line)) for line in text.splitlines())
    after = sum(bool(pattern.search(line)) for line in after_text.splitlines())
    print(f"G2D_IOMMU_FAULT_DELTA master=5 before={before} after={after} delta={after-before}")
elif mode == "clocks":
    names = {"g2d", "bus-g2d", "mbus-g2d", "g2d-bus-rot", "g2d-rot", "g2d-rot-div"}
    rows = [f"G2D_CLOCK text={line.strip()}" for line in text.splitlines()
            if line.split() and line.split()[0] in names]
    bounded(rows, 450, "G2D_CLOCK state=absent")
elif mode == "reset-runtime":
    runtime = read(sys.argv[3]).strip() if len(sys.argv) == 4 else ""
    reset_root = pathlib.Path(path)
    exposed = reset_root.exists() and any(p.is_file() for p in reset_root.rglob("*") if p.name != ".")
    print(f"G2D_RESET state={'exposed' if exposed else 'not_exposed'} runtime_status={runtime or 'unavailable'}")
elif mode == "regs":
    root = pathlib.Path(path)
    rows = []
    try:
        candidates = [p for p in root.rglob("registers")
                      if re.search(r"64a8000|rotate", str(p), re.I)]
    except OSError:
        candidates = []
    for candidate in candidates[:1]:
        rows.append(f"G2D_REGS path={candidate}")
        for line in read(str(candidate), 4096).splitlines()[:16]:
            rows.append(f"G2D_REG text={line.strip()}")
    bounded(rows, 600, "G2D_REGS state=not_exposed")
elif mode == "compliance":
    rows = [f"G2D_STREAMING_COMPLIANCE text={line.strip()}" for line in text.splitlines()
            if "Total" in line or "FAIL" in line]
    bounded(rows, 300, "G2D_STREAMING_COMPLIANCE state=summary_absent")
else:
    raise SystemExit("G2D_DIAGNOSE_ERROR reason=mode")
